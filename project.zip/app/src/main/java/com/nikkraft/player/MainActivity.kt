package com.nikkraft.player

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.format.DateFormat
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Date

class MainActivity : ComponentActivity() {
    override fun onStop() {
        super.onStop()
        Engine.saveState()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Engine.init(applicationContext)
        try { startService(Intent(this, PlaybackService::class.java)) } catch (e: Exception) { }
        val audio = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        val perms = buildList {
            add(audio)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.toTypedArray()
        setContent {
            AppTheme {
                val ctx = LocalContext.current
                var granted by remember {
                    mutableStateOf(checkSelfPermission(audio) == PackageManager.PERMISSION_GRANTED)
                }
                val launcher = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestMultiplePermissions()
                ) { granted = it[audio] == true }
                LaunchedEffect(granted) {
                    if (granted && Engine.all.isEmpty()) {
                        val s = withContext(Dispatchers.IO) { loadSongs(ctx.applicationContext) }
                        Engine.setLibrary(s)
                    }
                }
                App(granted) { launcher.launch(perms) }
            }
        }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val cs = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = cs, content = content)
}

// ---------- модели UI ----------

data class Detail(val kind: String, val key: String, val title: String)

sealed interface Dlg
data class AddTo(val s: Song) : Dlg
data class EditTags(val s: Song) : Dlg
data class NewPl(val then: Song?) : Dlg
data class DelPl(val name: String) : Dlg
data class RenamePl(val name: String) : Dlg

fun albumKey(s: Song) = "${s.albumId}|${s.album}"

fun detailSongs(d: Detail): List<Song> = when (d.kind) {
    "album" -> Engine.all.filter { albumKey(it) == d.key }
    "artist" -> Engine.all.filter { it.artist == d.key }
    else -> {
        val byId = Engine.all.associateBy { it.id }
        Store.playlists.find { it.name == d.key }?.ids?.mapNotNull { byId[it] } ?: emptyList()
    }
}

fun fmt(ms: Int) = "%d:%02d".format(ms / 60000, ms / 1000 % 60)

// ---------- корневой экран ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(granted: Boolean, ask: () -> Unit) {
    val tabs = listOf("Треки", "Альбомы", "Исполнители", "Избранное", "Плейлисты")
    var tab by remember { mutableIntStateOf(0) }
    var detail by remember { mutableStateOf<Detail?>(null) }
    var full by remember { mutableStateOf(false) }
    var showEq by remember { mutableStateOf(false) }
    var dlg by remember { mutableStateOf<Dlg?>(null) }

    LaunchedEffect(Engine.playing) {
        while (Engine.playing) { Engine.pos = Engine.player.currentPosition.toInt(); delay(400) }
    }
    BackHandler(enabled = full || detail != null) { if (full) full = false else detail = null }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            topBar = {
                val d = detail
                if (d != null) {
                    TopAppBar(
                        title = { Text(d.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        navigationIcon = {
                            IconButton(onClick = { detail = null }) { Icon(Icons.Rounded.ArrowBack, null) }
                        }
                    )
                } else {
                    Column {
                        TopAppBar(
                            title = { Text("NekoLocalMusic") },
                            actions = {
                                SleepButton()
                                IconButton(onClick = { showEq = true }) { Icon(Icons.Rounded.Equalizer, null) }
                            }
                        )
                        ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp) {
                            tabs.forEachIndexed { i, t ->
                                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
                            }
                        }
                    }
                }
            },
            bottomBar = { MiniPlayer { full = true } }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                val d = detail
                when {
                    !granted -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                        FilledTonalButton(onClick = ask) { Text("Разрешить доступ к музыке") }
                    }
                    d != null -> DetailList(d) { dlg = it }
                    tab == 0 -> SongList(Engine.all, null, "Музыка не найдена") { dlg = it }
                    tab == 1 -> AlbumGrid { detail = it }
                    tab == 2 -> ArtistList { detail = it }
                    tab == 3 -> {
                        val f = Engine.all.filter { it.id in Store.favs }
                        SongList(f, null, "Нет избранных") { dlg = it }
                    }
                    else -> PlaylistList(open = { detail = it }) { dlg = it }
                }
            }
        }
        AnimatedVisibility(
            visible = full && Engine.current != null,
            enter = slideInVertically { it },
            exit = slideOutVertically { it }
        ) {
            FullPlayer(close = { full = false }, onEq = { showEq = true }, onDlg = { dlg = it })
        }
    }

    if (showEq) ModalBottomSheet(onDismissRequest = { showEq = false }) {
        key(Engine.effectsVersion) { EqPanel() }
    }
    Dialogs(dlg, close = { dlg = null }, onDlg = { dlg = it })
}

// ---------- общие элементы ----------

@Composable
fun Cover(s: Song, modifier: Modifier, corner: Dp = 12.dp, px: Int = 160) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, s.id, px) {
        value = null
        value = withContext(Dispatchers.IO) { loadCoverBitmap(ctx, s, px)?.asImageBitmap() }
    }
    Box(
        modifier.clip(RoundedCornerShape(corner)).background(MaterialTheme.colorScheme.secondaryContainer),
        Alignment.Center
    ) {
        val b = bmp
        if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Rounded.MusicNote, null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
    }
}

@Composable
fun SleepButton() {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    if (Engine.sleepUntil > 0) {
        Text(
            DateFormat.getTimeFormat(ctx).format(Date(Engine.sleepUntil)),
            style = MaterialTheme.typography.labelMedium
        )
    }
    Box {
        IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.Bedtime, null) }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            listOf(0 to "Таймер сна: выкл", 15 to "15 минут", 30 to "30 минут", 60 to "60 минут")
                .forEach { (m, t) ->
                    DropdownMenuItem(text = { Text(t) }, onClick = { Engine.sleep(m); menu = false })
                }
        }
    }
}

@Composable
fun Controls() {
    val off = MaterialTheme.colorScheme.onSurfaceVariant
    val on = MaterialTheme.colorScheme.primary
    Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
        IconButton(onClick = { Engine.toggleShuffle() }) {
            Icon(Icons.Rounded.Shuffle, null, tint = if (Engine.shuffle) on else off)
        }
        IconButton(onClick = { Engine.prev() }) { Icon(Icons.Rounded.SkipPrevious, null) }
        FilledIconButton(onClick = { Engine.toggle() }, modifier = Modifier.size(64.dp)) {
            Icon(if (Engine.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null)
        }
        IconButton(onClick = { Engine.next() }) { Icon(Icons.Rounded.SkipNext, null) }
        IconButton(onClick = { Engine.cycleRepeat() }) {
            Icon(
                if (Engine.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                null,
                tint = if (Engine.repeat == Player.REPEAT_MODE_OFF) off else on
            )
        }
    }
}

// ---------- мини-плеер и полноэкранный плеер ----------

@Composable
fun MiniPlayer(onOpen: () -> Unit) {
    val s = Engine.current ?: return
    Surface(tonalElevation = 3.dp, modifier = Modifier.clickable(onClick = onOpen)) {
        Column(Modifier.navigationBarsPadding()) {
            LinearProgressIndicator(
                progress = { (Engine.pos / maxOf(1f, s.duration.toFloat())).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth()
            )
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Cover(s, Modifier.size(44.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(s.artist, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = { Engine.toggle() }) {
                    Icon(if (Engine.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null)
                }
                IconButton(onClick = { Engine.next() }) { Icon(Icons.Rounded.SkipNext, null) }
            }
        }
    }
}

@Composable
fun FullPlayer(close: () -> Unit, onEq: () -> Unit, onDlg: (Dlg) -> Unit) {
    val s = Engine.current ?: return
    var drag by remember { mutableStateOf<Float?>(null) }
    val fav = s.id in Store.favs
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
        Column(
            Modifier.fillMaxSize().systemBarsPadding()
                .verticalScroll(rememberScrollState()).padding(horizontal = 24.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = close) { Icon(Icons.Rounded.KeyboardArrowDown, null) }
                Text(
                    "Сейчас играет", Modifier.weight(1f), textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.titleSmall
                )
                IconButton(onClick = onEq) { Icon(Icons.Rounded.Equalizer, null) }
            }
            Spacer(Modifier.height(16.dp))
            Cover(s, Modifier.fillMaxWidth().aspectRatio(1f), corner = 28.dp, px = 800)
            Spacer(Modifier.height(24.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        s.title, style = MaterialTheme.typography.headlineSmall,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        s.artist, style = MaterialTheme.typography.bodyLarge, color = dim,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = { Store.toggleFav(s.id) }) {
                    Icon(
                        if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null,
                        tint = if (fav) MaterialTheme.colorScheme.primary else dim
                    )
                }
            }
            Slider(
                value = drag ?: Engine.pos.toFloat(),
                onValueChange = { drag = it },
                onValueChangeFinished = {
                    drag?.let { Engine.player.seekTo(it.toLong()); Engine.pos = it.toInt() }
                    drag = null
                },
                valueRange = 0f..maxOf(1f, s.duration.toFloat())
            )
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                Text(fmt(drag?.toInt() ?: Engine.pos), style = MaterialTheme.typography.labelSmall)
                Text(fmt(s.duration.toInt()), style = MaterialTheme.typography.labelSmall)
            }
            Spacer(Modifier.height(8.dp))
            Controls()
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
                IconButton(onClick = { onDlg(AddTo(s)) }) { Icon(Icons.Rounded.PlaylistAdd, null) }
                SleepButton()
                IconButton(onClick = { onDlg(EditTags(s)) }) { Icon(Icons.Rounded.Edit, null) }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

// ---------- списки ----------

@Composable
fun SongMenu(s: Song, pl: String?, onDlg: (Dlg) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val fav = s.id in Store.favs
    Box {
        IconButton(onClick = { open = true }) { Icon(Icons.Rounded.MoreVert, null) }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(
                text = { Text(if (fav) "Убрать из избранного" else "В избранное") },
                onClick = { Store.toggleFav(s.id); open = false }
            )
            DropdownMenuItem(text = { Text("В плейлист") }, onClick = { onDlg(AddTo(s)); open = false })
            if (pl != null) {
                DropdownMenuItem(
                    text = { Text("Переместить выше") },
                    onClick = { Store.move(pl, s.id, -1); open = false }
                )
                DropdownMenuItem(
                    text = { Text("Переместить ниже") },
                    onClick = { Store.move(pl, s.id, 1); open = false }
                )
                DropdownMenuItem(
                    text = { Text("Убрать из плейлиста") },
                    onClick = { Store.removeFrom(pl, s.id); open = false }
                )
            }
            DropdownMenuItem(text = { Text("Изменить теги") }, onClick = { onDlg(EditTags(s)); open = false })
        }
    }
}

@Composable
fun SongList(songs: List<Song>, pl: String? = null, empty: String = "Пусто", onDlg: (Dlg) -> Unit) {
    if (songs.isEmpty()) {
        Box(Modifier.fillMaxSize(), Alignment.Center) {
            Text(empty, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        return
    }
    val cur = Engine.current?.id
    LazyColumn(Modifier.fillMaxSize()) {
        itemsIndexed(songs, key = { _, s -> s.id }) { i, s ->
            ListItem(
                leadingContent = { Cover(s, Modifier.size(48.dp)) },
                headlineContent = { Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                supportingContent = { Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                trailingContent = { SongMenu(s, pl, onDlg) },
                colors = ListItemDefaults.colors(
                    containerColor = if (s.id == cur) MaterialTheme.colorScheme.secondaryContainer
                    else Color.Transparent
                ),
                modifier = Modifier.clickable { Engine.play(songs, i) }
            )
        }
    }
}

@Composable
fun DetailList(d: Detail, onDlg: (Dlg) -> Unit) {
    SongList(detailSongs(d), if (d.kind == "pl") d.key else null, "Пусто", onDlg)
}

@Composable
fun AlbumGrid(open: (Detail) -> Unit) {
    val groups = remember(Engine.all) {
        Engine.all.groupBy { albumKey(it) }.values.toList().sortedBy { it[0].album.lowercase() }
    }
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(groups, key = { albumKey(it[0]) }) { g ->
            val s = g[0]
            Column(Modifier.clickable { open(Detail("album", albumKey(s), s.album)) }) {
                Cover(s, Modifier.fillMaxWidth().aspectRatio(1f), corner = 16.dp, px = 400)
                Spacer(Modifier.height(8.dp))
                Text(s.album, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    s.artist, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun ArtistList(open: (Detail) -> Unit) {
    val groups = remember(Engine.all) {
        Engine.all.groupBy { it.artist }.toList().sortedBy { it.first.lowercase() }
    }
    LazyColumn(Modifier.fillMaxSize()) {
        items(groups, key = { it.first }) { (name, songs) ->
            ListItem(
                leadingContent = {
                    Box(
                        Modifier.size(48.dp).clip(CircleShape).background(MaterialTheme.colorScheme.secondaryContainer),
                        Alignment.Center
                    ) { Text(name.take(1).uppercase(), color = MaterialTheme.colorScheme.onSecondaryContainer) }
                },
                headlineContent = { Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                supportingContent = { Text("Треков: ${songs.size}") },
                modifier = Modifier.clickable { open(Detail("artist", name, name)) }
            )
        }
    }
}

@Composable
fun PlaylistList(open: (Detail) -> Unit, onDlg: (Dlg) -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            ListItem(
                leadingContent = { Icon(Icons.Rounded.Add, null) },
                headlineContent = { Text("Новый плейлист") },
                modifier = Modifier.clickable { onDlg(NewPl(null)) }
            )
        }
        items(Store.playlists, key = { it.name }) { p ->
            ListItem(
                leadingContent = { Icon(Icons.Rounded.QueueMusic, null) },
                headlineContent = { Text(p.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                supportingContent = { Text("Треков: ${p.ids.size}") },
                trailingContent = { PlMenu(p.name, onDlg) },
                modifier = Modifier.clickable { open(Detail("pl", p.name, p.name)) }
            )
        }
    }
}

// ---------- диалоги ----------

@Composable
fun Dialogs(d: Dlg?, close: () -> Unit, onDlg: (Dlg?) -> Unit) {
    when (d) {
        null -> {}
        is AddTo -> AlertDialog(
            onDismissRequest = close,
            title = { Text("В плейлист") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    TextButton(onClick = { onDlg(NewPl(d.s)) }) {
                        Icon(Icons.Rounded.Add, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Новый плейлист")
                    }
                    Store.playlists.forEach { p ->
                        TextButton(onClick = { Store.addTo(p.name, d.s.id); close() }) { Text(p.name) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = close) { Text("Отмена") } }
        )
        is NewPl -> NewPlDialog(d, close)
        is RenamePl -> RenameDialog(d.name, close)
        is EditTags -> EditDialog(d.s, close)
        is DelPl -> AlertDialog(
            onDismissRequest = close,
            title = { Text("Удалить плейлист?") },
            text = { Text(d.name) },
            confirmButton = { TextButton(onClick = { Store.deletePlaylist(d.name); close() }) { Text("Удалить") } },
            dismissButton = { TextButton(onClick = close) { Text("Отмена") } }
        )
    }
}

@Composable
fun PlMenu(name: String, onDlg: (Dlg) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }) { Icon(Icons.Rounded.MoreVert, null) }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(text = { Text("Переименовать") }, onClick = { onDlg(RenamePl(name)); open = false })
            DropdownMenuItem(text = { Text("Удалить") }, onClick = { onDlg(DelPl(name)); open = false })
        }
    }
}

@Composable
fun RenameDialog(old: String, close: () -> Unit) {
    var name by remember { mutableStateOf(old) }
    AlertDialog(
        onDismissRequest = close,
        title = { Text("Переименовать плейлист") },
        text = { OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Название") }) },
        confirmButton = {
            TextButton(onClick = { Store.renamePlaylist(old, name.trim()); close() }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = close) { Text("Отмена") } }
    )
}

@Composable
fun NewPlDialog(d: NewPl, close: () -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = close,
        title = { Text("Новый плейлист") },
        text = {
            OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Название") })
        },
        confirmButton = {
            TextButton(onClick = {
                val n = name.trim()
                if (n.isNotEmpty()) {
                    Store.createPlaylist(n)
                    d.then?.let { Store.addTo(n, it.id) }
                    close()
                }
            }) { Text("Создать") }
        },
        dismissButton = { TextButton(onClick = close) { Text("Отмена") } }
    )
}

@Composable
fun EditDialog(s: Song, close: () -> Unit) {
    var t by remember { mutableStateOf(s.title) }
    var a by remember { mutableStateOf(s.artist) }
    var b by remember { mutableStateOf(s.album) }
    AlertDialog(
        onDismissRequest = close,
        title = { Text("Изменить теги") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(t, { t = it }, singleLine = true, label = { Text("Название") })
                OutlinedTextField(a, { a = it }, singleLine = true, label = { Text("Исполнитель") })
                OutlinedTextField(b, { b = it }, singleLine = true, label = { Text("Альбом") })
                Text(
                    "Меняется только в этом приложении, сам файл не затрагивается",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                Store.setEdit(
                    s.id,
                    TagEdit(t.trim().ifEmpty { s.title }, a.trim().ifEmpty { s.artist }, b.trim().ifEmpty { s.album })
                )
                Engine.applyEdits()
                close()
            }) { Text("Сохранить") }
        },
        dismissButton = {
            Row {
                TextButton(onClick = { Store.setEdit(s.id, null); Engine.applyEdits(); close() }) { Text("Сбросить") }
                TextButton(onClick = close) { Text("Отмена") }
            }
        }
    )
}

// ---------- эквалайзер ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EqPanel() {
    val eq = Engine.eq
    val bass = Engine.bass
    if (eq == null) {
        Text("Эквалайзер недоступен на этом устройстве", Modifier.padding(24.dp))
        return
    }
    val lo = eq.bandLevelRange[0].toFloat()
    val hi = eq.bandLevelRange[1].toFloat()
    val bands = eq.numberOfBands.toInt()
    val levels = remember {
        mutableStateListOf<Float>().apply {
            for (b in 0 until bands) add(eq.getBandLevel(b.toShort()).toFloat())
        }
    }
    var on by remember { mutableStateOf(eq.enabled) }
    var preset by remember { mutableIntStateOf(-1) }
    val bassOk = bass != null && bass.strengthSupported
    var bassVal by remember { mutableFloatStateOf(if (bassOk) bass!!.roundedStrength.toFloat() else 0f) }

    Column(
        Modifier.verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp).padding(bottom = 32.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Эквалайзер", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            Switch(checked = on, onCheckedChange = { on = it; eq.enabled = it; bass?.enabled = it })
        }
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            for (i in 0 until eq.numberOfPresets.toInt()) {
                FilterChip(
                    selected = preset == i,
                    onClick = {
                        eq.usePreset(i.toShort()); preset = i
                        for (b in 0 until bands) levels[b] = eq.getBandLevel(b.toShort()).toFloat()
                    },
                    label = { Text(eq.getPresetName(i.toShort())) }
                )
            }
        }
        for (b in 0 until bands) {
            val hz = eq.getCenterFreq(b.toShort()) / 1000
            Text(
                if (hz >= 1000) "%.1f кГц".format(hz / 1000f) else "$hz Гц",
                style = MaterialTheme.typography.labelMedium
            )
            Slider(
                value = levels[b],
                onValueChange = {
                    levels[b] = it; preset = -1
                    eq.setBandLevel(b.toShort(), it.toInt().toShort())
                },
                valueRange = lo..hi
            )
        }
        if (bassOk) {
            Text("Усиление баса", style = MaterialTheme.typography.labelMedium)
            Slider(
                value = bassVal,
                onValueChange = { bassVal = it; bass!!.setStrength(it.toInt().toShort()) },
                valueRange = 0f..1000f
            )
        }
        TextButton(onClick = {
            preset = -1
            for (b in 0 until bands) { levels[b] = 0f; eq.setBandLevel(b.toShort(), 0) }
            if (bassOk) { bassVal = 0f; bass!!.setStrength(0) }
        }) { Text("Сбросить") }
    }
}
