package com.nikkraft.player

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.format.DateFormat
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Date

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Engine.init(applicationContext)
        try { startService(Intent(this, PlaybackService::class.java)) } catch (e: Exception) { }
        val audio = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        val perms = buildList {
            add(audio)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.toTypedArray()
        setContent {
            AppTheme {
                var granted by remember {
                    mutableStateOf(checkSelfPermission(audio) == PackageManager.PERMISSION_GRANTED)
                }
                val launcher = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestMultiplePermissions()
                ) { granted = it[audio] == true }
                LaunchedEffect(granted) {
                    if (granted && Engine.list.isEmpty()) {
                        val s = withContext(Dispatchers.IO) { loadSongs(applicationContext) }
                        Engine.setSongs(s)
                    }
                }
                PlayerScreen(granted) { launcher.launch(perms) }
            }
        }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val cs = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = cs, content = content)
}

suspend fun loadCover(ctx: Context, s: Song, size: Int): ImageBitmap? = withContext(Dispatchers.IO) {
    try {
        val bmp = if (Build.VERSION.SDK_INT >= 29) {
            ctx.contentResolver.loadThumbnail(s.uri, Size(size, size), null)
        } else {
            ctx.contentResolver.openInputStream(
                Uri.parse("content://media/external/audio/albumart/${s.albumId}")
            )?.use { BitmapFactory.decodeStream(it) }
        }
        bmp?.asImageBitmap()
    } catch (e: Exception) { null }
}

@Composable
fun Cover(s: Song, size: Dp) {
    val ctx = LocalContext.current
    val px = with(LocalDensity.current) { size.roundToPx() }
    val bmp by produceState<ImageBitmap?>(null, s.id) { value = loadCover(ctx, s, px) }
    Box(
        Modifier.size(size).clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.secondaryContainer),
        Alignment.Center
    ) {
        val b = bmp
        if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Rounded.MusicNote, null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen(granted: Boolean, ask: () -> Unit) {
    val ctx = LocalContext.current
    var showEq by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    LaunchedEffect(Engine.playing) {
        while (Engine.playing) { Engine.pos = Engine.player.currentPosition.toInt(); delay(400) }
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Музыка") },
                actions = {
                    if (Engine.sleepUntil > 0) {
                        Text(
                            DateFormat.getTimeFormat(ctx).format(Date(Engine.sleepUntil)),
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.Bedtime, null) }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            listOf(0 to "Таймер сна: выкл", 15 to "15 минут", 30 to "30 минут", 60 to "60 минут")
                                .forEach { (m, t) ->
                                    DropdownMenuItem(text = { Text(t) }, onClick = { Engine.sleep(m); menu = false })
                                }
                        }
                    }
                    IconButton(onClick = { showEq = true }) { Icon(Icons.Rounded.Equalizer, null) }
                }
            )
        },
        bottomBar = { if (Engine.index in Engine.list.indices) NowPlaying() }
    ) { pad ->
        if (!granted) {
            Box(Modifier.fillMaxSize().padding(pad), Alignment.Center) {
                FilledTonalButton(onClick = ask) { Text("Разрешить доступ к музыке") }
            }
        } else {
            LazyColumn(Modifier.padding(pad)) {
                itemsIndexed(Engine.list, key = { _, s -> s.id }) { i, s ->
                    ListItem(
                        leadingContent = { Cover(s, 48.dp) },
                        headlineContent = { Text(s.title, maxLines = 1) },
                        supportingContent = { Text(s.artist, maxLines = 1) },
                        colors = ListItemDefaults.colors(
                            containerColor = if (i == Engine.index) MaterialTheme.colorScheme.secondaryContainer
                            else Color.Transparent
                        ),
                        modifier = Modifier.clickable { Engine.play(i) }
                    )
                }
            }
        }
    }
    if (showEq) ModalBottomSheet(onDismissRequest = { showEq = false }) {
        key(Engine.effectsVersion) { EqPanel() }
    }
}

@Composable
fun NowPlaying() {
    val s = Engine.list[Engine.index]
    var drag by remember { mutableStateOf<Float?>(null) }
    val off = MaterialTheme.colorScheme.onSurfaceVariant
    val on = MaterialTheme.colorScheme.primary
    Surface(tonalElevation = 3.dp) {
        Column(Modifier.navigationBarsPadding().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Cover(s, 56.dp)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(s.title, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                    Text(s.artist, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                }
            }
            Slider(
                value = drag ?: Engine.pos.toFloat(),
                onValueChange = { drag = it },
                onValueChangeFinished = {
                    drag?.let { Engine.player.seekTo(it.toLong()); Engine.pos = it.toInt() }
                    drag = null
                },
                valueRange = 0f..maxOf(1f, s.duration.toFloat())
            )
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
                IconButton(onClick = { Engine.toggleShuffle() }) {
                    Icon(Icons.Rounded.Shuffle, null, tint = if (Engine.shuffle) on else off)
                }
                IconButton(onClick = { Engine.prev() }) { Icon(Icons.Rounded.SkipPrevious, null) }
                FilledIconButton(onClick = { Engine.toggle() }, modifier = Modifier.size(56.dp)) {
                    Icon(if (Engine.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null)
                }
                IconButton(onClick = { Engine.next() }) { Icon(Icons.Rounded.SkipNext, null) }
                IconButton(onClick = { Engine.cycleRepeat() }) {
                    Icon(
                        if (Engine.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                        null,
                        tint = if (Engine.repeat == Player.REPEAT_MODE_OFF) off else on
                    )
                }
            }
        }
    }
}

@Composable
fun EqPanel() {
    val eq = Engine.eq
    val bass = Engine.bass
    if (eq == null) {
        Text("Эквалайзер недоступен на этом устройстве", Modifier.padding(24.dp))
        return
    }
    val lo = eq.bandLevelRange[0].toFloat()
    val hi = eq.bandLevelRange[1].toFloat()
    val bands = eq.numberOfBands.toInt()
    val levels = remember {
        mutableStateListOf<Float>().apply {
            for (b in 0 until bands) add(eq.getBandLevel(b.toShort()).toFloat())
        }
    }
    var on by remember { mutableStateOf(eq.enabled) }
    var preset by remember { mutableIntStateOf(-1) }
    val bassOk = bass != null && bass.strengthSupported
    var bassVal by remember { mutableFloatStateOf(if (bassOk) bass!!.roundedStrength.toFloat() else 0f) }

    Column(
        Modifier.verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp).padding(bottom = 32.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Эквалайзер", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            Switch(checked = on, onCheckedChange = { on = it; eq.enabled = it; bass?.enabled = it })
        }
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            for (i in 0 until eq.numberOfPresets.toInt()) {
                FilterChip(
                    selected = preset == i,
                    onClick = {
                        eq.usePreset(i.toShort()); preset = i
                        for (b in 0 until bands) levels[b] = eq.getBandLevel(b.toShort()).toFloat()
                    },
                    label = { Text(eq.getPresetName(i.toShort())) }
                )
            }
        }
        for (b in 0 until bands) {
            val hz = eq.getCenterFreq(b.toShort()) / 1000
            Text(
                if (hz >= 1000) "%.1f кГц".format(hz / 1000f) else "$hz Гц",
                style = MaterialTheme.typography.labelMedium
            )
            Slider(
                value = levels[b],
                onValueChange = {
                    levels[b] = it; preset = -1
                    eq.setBandLevel(b.toShort(), it.toInt().toShort())
                },
                valueRange = lo..hi
            )
        }
        if (bassOk) {
            Text("Усиление баса", style = MaterialTheme.typography.labelMedium)
            Slider(
                value = bassVal,
                onValueChange = { bassVal = it; bass!!.setStrength(it.toInt().toShort()) },
                valueRange = 0f..1000f
            )
        }
        TextButton(onClick = {
            preset = -1
            for (b in 0 until bands) { levels[b] = 0f; eq.setBandLevel(b.toShort(), 0) }
            if (bassOk) { bassVal = 0f; bass!!.setStrength(0) }
        }) { Text("Сбросить") }
    }
}
