package com.nikkraft.player

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.view.View
import android.widget.RemoteViews

open class PlayerWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        Widget.update(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val a = intent.action ?: return
        if (a != Widget.PLAY && a != Widget.NEXT && a != Widget.PREV) return
        val app = context.applicationContext
        Engine.init(app)
        Engine.ensureLoaded(app)
        try { app.startService(Intent(app, PlaybackService::class.java)) } catch (e: Exception) { }
        when (a) {
            Widget.PLAY -> Engine.toggle()
            Widget.NEXT -> Engine.next()
            else -> Engine.prev()
        }
    }
}

class PlayerWidgetBig : PlayerWidget()

object Widget {
    const val PLAY = "com.nikkraft.nekolocalmusic.W_PLAY"
    const val NEXT = "com.nikkraft.nekolocalmusic.W_NEXT"
    const val PREV = "com.nikkraft.nekolocalmusic.W_PREV"

    private fun broadcast(ctx: Context, action: String, code: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, code, Intent(ctx, PlayerWidget::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun fit(b: Bitmap?, size: Int): Bitmap? {
        if (b == null) return null
        val m = maxOf(b.width, b.height)
        if (m <= size) return b
        val k = size.toFloat() / m
        return Bitmap.createScaledBitmap(
            b, (b.width * k).toInt().coerceAtLeast(1), (b.height * k).toInt().coerceAtLeast(1), true
        )
    }

    fun update(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val small = mgr.getAppWidgetIds(ComponentName(ctx, PlayerWidget::class.java))
        val big = mgr.getAppWidgetIds(ComponentName(ctx, PlayerWidgetBig::class.java))
        if (small.isEmpty() && big.isEmpty()) return
        val s = Engine.current
        val playing = Engine.playing
        Thread {
            val openApp = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            if (small.isNotEmpty()) {
                val bmp = fit(s?.let { loadCoverBitmap(ctx, it, 128) }, 128)
                val v = RemoteViews(ctx.packageName, R.layout.widget)
                v.setTextViewText(R.id.w_title, s?.title ?: "NekoLocalMusic")
                v.setTextViewText(R.id.w_artist, s?.artist ?: "")
                v.setImageViewResource(R.id.w_play, if (playing) R.drawable.ic_pause else R.drawable.ic_play)
                if (bmp != null) v.setImageViewBitmap(R.id.w_cover, bmp)
                else v.setImageViewResource(R.id.w_cover, R.drawable.ic_note)
                v.setOnClickPendingIntent(R.id.w_play, broadcast(ctx, PLAY, 1))
                v.setOnClickPendingIntent(R.id.w_next, broadcast(ctx, NEXT, 2))
                v.setOnClickPendingIntent(R.id.w_prev, broadcast(ctx, PREV, 3))
                v.setOnClickPendingIntent(R.id.w_root, openApp)
                try { mgr.updateAppWidget(small, v) } catch (e: Exception) { }
            }
            if (big.isNotEmpty()) {
                val bmp = fit(s?.let { loadCoverBitmap(ctx, it, 384) }, 384)
                val v = RemoteViews(ctx.packageName, R.layout.widget_big)
                v.setTextViewText(R.id.b_title, s?.title ?: "NekoLocalMusic")
                v.setTextViewText(R.id.b_artist, s?.artist ?: "")
                v.setImageViewResource(R.id.b_play, if (playing) R.drawable.ic_pause_w else R.drawable.ic_play_w)
                if (bmp != null) {
                    v.setImageViewBitmap(R.id.b_cover, bmp)
                    v.setViewVisibility(R.id.b_cover, View.VISIBLE)
                } else v.setViewVisibility(R.id.b_cover, View.INVISIBLE)
                v.setOnClickPendingIntent(R.id.b_play, broadcast(ctx, PLAY, 1))
                v.setOnClickPendingIntent(R.id.b_next, broadcast(ctx, NEXT, 2))
                v.setOnClickPendingIntent(R.id.b_prev, broadcast(ctx, PREV, 3))
                v.setOnClickPendingIntent(R.id.b_root, openApp)
                try { mgr.updateAppWidget(big, v) } catch (e: Exception) { }
            }
        }.start()
    }
}
