package com.nikkraft.player

import android.content.ContentUris
import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.compose.runtime.*
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

data class Song(
    val id: Long, val title: String, val artist: String,
    val duration: Long, val albumId: Long
) {
    val uri: Uri get() = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
    fun item(): MediaItem = MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setArtworkUri(Uri.parse("content://media/external/audio/albumart/$albumId"))
                .build()
        ).build()
}

fun loadSongs(ctx: Context): List<Song> {
    val out = mutableListOf<Song>()
    val a = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val cols = arrayOf(
        MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION,
        MediaStore.Audio.Media.ALBUM_ID
    )
    ctx.contentResolver.query(
        a, cols,
        "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 30000",
        null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE"
    )?.use { c ->
        while (c.moveToNext()) out += Song(
            c.getLong(0), c.getString(1) ?: "?", c.getString(2) ?: "",
            c.getLong(3), c.getLong(4)
        )
    }
    return out
}

object Engine {
    private var inited = false
    lateinit var player: ExoPlayer
    var eq: Equalizer? = null
    var bass: BassBoost? = null
    var effectsVersion by mutableIntStateOf(0)
    var list by mutableStateOf(listOf<Song>())
    var index by mutableIntStateOf(-1)
    var playing by mutableStateOf(false)
    var shuffle by mutableStateOf(false)
    var repeat by mutableIntStateOf(Player.REPEAT_MODE_ALL)
    var pos by mutableIntStateOf(0)
    var sleepUntil by mutableLongStateOf(0L)

    private val handler = Handler(Looper.getMainLooper())
    private val sleepRun = Runnable { player.pause(); sleepUntil = 0L }

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        player = ExoPlayer.Builder(ctx)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA).build(), true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        player.repeatMode = Player.REPEAT_MODE_ALL
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
                index = player.currentMediaItemIndex
            }
            override fun onShuffleModeEnabledChanged(enabled: Boolean) { shuffle = enabled }
            override fun onRepeatModeChanged(mode: Int) { repeat = mode }
            override fun onAudioSessionIdChanged(audioSessionId: Int) { attachEffects(audioSessionId) }
        })
        attachEffects(player.audioSessionId)
    }

    private fun attachEffects(session: Int) {
        eq?.release(); bass?.release()
        eq = try { Equalizer(0, session).apply { enabled = true } } catch (e: Exception) { null }
        bass = try { BassBoost(0, session).apply { enabled = true } } catch (e: Exception) { null }
        effectsVersion++
    }

    fun setSongs(s: List<Song>) {
        list = s
        player.setMediaItems(s.map { it.item() })
    }

    fun play(i: Int) {
        if (list.isEmpty()) return
        player.seekTo(i, 0)
        player.prepare()
        player.play()
        index = i
    }

    fun toggle() {
        if (list.isEmpty()) return
        if (player.isPlaying) player.pause() else {
            if (player.playbackState == Player.STATE_IDLE) player.prepare()
            player.play()
        }
    }

    fun next() { if (player.hasNextMediaItem()) player.seekToNextMediaItem() else player.seekTo(0, 0) }
    fun prev() { if (player.currentPosition > 3000) player.seekTo(0) else player.seekToPreviousMediaItem() }

    fun toggleShuffle() { player.shuffleModeEnabled = !player.shuffleModeEnabled }
    fun cycleRepeat() {
        player.repeatMode = when (player.repeatMode) {
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_OFF
            else -> Player.REPEAT_MODE_ALL
        }
    }

    fun sleep(minutes: Int) {
        handler.removeCallbacks(sleepRun)
        if (minutes > 0) {
            handler.postDelayed(sleepRun, minutes * 60_000L)
            sleepUntil = System.currentTimeMillis() + minutes * 60_000L
        } else sleepUntil = 0L
    }
}
