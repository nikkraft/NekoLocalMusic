package com.nikkraft.player

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import androidx.compose.runtime.*
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

data class Song(
    val id: Long, val title: String, val artist: String, val album: String,
    val duration: Long, val albumId: Long
) {
    val uri: Uri get() = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
    fun item(): MediaItem = MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(Uri.parse("content://media/external/audio/albumart/$albumId"))
                .build()
        ).build()
}

fun loadSongs(ctx: Context): List<Song> {
    val out = mutableListOf<Song>()
    val cols = arrayOf(
        MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM,
        MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.ALBUM_ID
    )
    ctx.contentResolver.query(
        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cols,
        "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 30000",
        null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE"
    )?.use { c ->
        while (c.moveToNext()) out += Song(
            c.getLong(0), c.getString(1) ?: "?", c.getString(2) ?: "",
            c.getString(3) ?: "", c.getLong(4), c.getLong(5)
        )
    }
    return out
}

fun loadCoverBitmap(ctx: Context, s: Song, size: Int): Bitmap? = try {
    if (Build.VERSION.SDK_INT >= 29) {
        ctx.contentResolver.loadThumbnail(s.uri, Size(size, size), null)
    } else {
        ctx.contentResolver.openInputStream(
            Uri.parse("content://media/external/audio/albumart/${s.albumId}")
        )?.use { BitmapFactory.decodeStream(it) }
    }
} catch (e: Exception) { null }

object Engine {
    private var inited = false
    private lateinit var appCtx: Context
    lateinit var player: ExoPlayer
    var eq: Equalizer? = null
    var bass: BassBoost? = null
    var effectsVersion by mutableIntStateOf(0)

    var raw = listOf<Song>()
    var all by mutableStateOf(listOf<Song>())
    var queue by mutableStateOf(listOf<Song>())
    var index by mutableIntStateOf(-1)
    val current: Song? get() = queue.getOrNull(index)
    var playing by mutableStateOf(false)
    var shuffle by mutableStateOf(false)
    var repeat by mutableIntStateOf(Player.REPEAT_MODE_ALL)
    var pos by mutableIntStateOf(0)
    var sleepUntil by mutableLongStateOf(0L)

    private val handler = Handler(Looper.getMainLooper())
    private val sleepRun = Runnable { player.pause(); sleepUntil = 0L }
    private val saver = object : Runnable {
        override fun run() {
            saveState()
            if (playing) handler.postDelayed(this, 5000)
        }
    }

    /** Запомнить текущий трек, позицию и очередь, чтобы продолжить после перезапуска. */
    fun saveState() {
        if (!inited) return
        val s = current ?: return
        val same = queue.size == all.size && queue.indices.all { queue[it].id == all[it].id }
        Store.saveLast(
            s.id, player.currentPosition,
            if (same) "" else queue.joinToString(",") { it.id.toString() }
        )
    }

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        appCtx = ctx.applicationContext
        Store.init(appCtx)
        player = ExoPlayer.Builder(appCtx)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA).build(), true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        player.repeatMode = Player.REPEAT_MODE_ALL
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playing = isPlaying
                handler.removeCallbacks(saver)
                if (isPlaying) handler.postDelayed(saver, 5000) else saveState()
                Widget.update(appCtx)
            }
            override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
                index = player.currentMediaItemIndex
                if (reason != Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED) saveState()
                Widget.update(appCtx)
            }
            override fun onShuffleModeEnabledChanged(enabled: Boolean) { shuffle = enabled }
            override fun onRepeatModeChanged(mode: Int) { repeat = mode }
            override fun onAudioSessionIdChanged(audioSessionId: Int) { attachEffects(audioSessionId) }
        })
        attachEffects(player.audioSessionId)
    }

    private fun attachEffects(session: Int) {
        eq?.release(); bass?.release()
        eq = try { Equalizer(0, session).apply { enabled = true } } catch (e: Exception) { null }
        bass = try { BassBoost(0, session).apply { enabled = true } } catch (e: Exception) { null }
        effectsVersion++
    }

    /** Синхронная загрузка библиотеки (для сервиса и виджета), если есть разрешение. */
    fun ensureLoaded(ctx: Context) {
        if (all.isNotEmpty()) return
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ctx.checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) return
        setLibrary(loadSongs(ctx))
    }

    fun setLibrary(s: List<Song>) { raw = s; applyEdits() }

    fun applyEdits() {
        all = raw.map { s ->
            Store.edits[s.id]?.let { s.copy(title = it.title, artist = it.artist, album = it.album) } ?: s
        }
        if (queue.isEmpty()) {
            val byId = all.associateBy { it.id }
            val saved = Store.lastQueue().split(",").mapNotNull { it.toLongOrNull() }.mapNotNull { byId[it] }
            val q = if (saved.isNotEmpty()) saved else all
            val li = q.indexOfFirst { it.id == Store.lastId() }
            queue = q
            if (q.isNotEmpty()) {
                if (li >= 0) {
                    val p = Store.lastPos().coerceAtLeast(0L)
                    player.setMediaItems(q.map { it.item() }, li, p)
                    index = li
                    pos = p.toInt()
                } else player.setMediaItems(q.map { it.item() })
            }
        } else {
            val byId = all.associateBy { it.id }
            val nq = queue.map { byId[it.id] ?: it }
            nq.forEachIndexed { i, s -> if (s != queue[i]) player.replaceMediaItem(i, s.item()) }
            queue = nq
        }
        Widget.update(appCtx)
    }

    fun play(q: List<Song>, i: Int) {
        if (q.isEmpty()) return
        if (q.map { it.id } != queue.map { it.id }) {
            queue = q
            player.setMediaItems(q.map { it.item() })
        }
        player.seekTo(i, 0)
        player.prepare()
        player.play()
        index = i
    }

    fun toggle() {
        if (queue.isEmpty()) return
        if (player.isPlaying) player.pause() else {
            if (player.playbackState == Player.STATE_IDLE) player.prepare()
            player.play()
        }
    }

    fun next() {
        if (queue.isEmpty()) return
        if (player.playbackState == Player.STATE_IDLE) player.prepare()
        if (player.hasNextMediaItem()) player.seekToNextMediaItem() else player.seekTo(0, 0)
    }

    fun prev() {
        if (queue.isEmpty()) return
        if (player.playbackState == Player.STATE_IDLE) player.prepare()
        if (player.currentPosition > 3000) player.seekTo(0) else player.seekToPreviousMediaItem()
    }

    fun toggleShuffle() { player.shuffleModeEnabled = !player.shuffleModeEnabled }

    fun cycleRepeat() {
        player.repeatMode = when (player.repeatMode) {
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_OFF
            else -> Player.REPEAT_MODE_ALL
        }
    }

    fun sleep(minutes: Int) {
        handler.removeCallbacks(sleepRun)
        if (minutes > 0) {
            handler.postDelayed(sleepRun, minutes * 60_000L)
            sleepUntil = System.currentTimeMillis() + minutes * 60_000L
        } else sleepUntil = 0L
    }
}
