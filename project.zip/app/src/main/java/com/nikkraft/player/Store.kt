package com.nikkraft.player

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

data class Playlist(val name: String, val ids: List<Long>)
data class TagEdit(val title: String, val artist: String, val album: String)

object Store {
    private var sp: SharedPreferences? = null
    var favs by mutableStateOf(setOf<Long>())
    var playlists by mutableStateOf(listOf<Playlist>())
    var edits by mutableStateOf(mapOf<Long, TagEdit>())

    fun init(ctx: Context) {
        if (sp != null) return
        val p = ctx.getSharedPreferences("player", Context.MODE_PRIVATE)
        sp = p
        favs = (p.getString("favs", "") ?: "").split(",").mapNotNull { it.toLongOrNull() }.toSet()
        playlists = try {
            val a = JSONArray(p.getString("pl", "[]"))
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                val ids = o.getJSONArray("i")
                Playlist(o.getString("n"), (0 until ids.length()).map { j -> ids.getLong(j) })
            }
        } catch (e: Exception) { emptyList() }
        edits = try {
            val o = JSONObject(p.getString("ed", "{}"))
            val m = mutableMapOf<Long, TagEdit>()
            for (k in o.keys()) {
                val e = o.getJSONObject(k)
                m[k.toLong()] = TagEdit(e.getString("t"), e.getString("a"), e.getString("b"))
            }
            m
        } catch (e: Exception) { emptyMap() }
    }

    private fun save() {
        val e = sp?.edit() ?: return
        val pl = JSONArray()
        playlists.forEach { pl.put(JSONObject().put("n", it.name).put("i", JSONArray(it.ids))) }
        val ed = JSONObject()
        edits.forEach { (k, v) ->
            ed.put(k.toString(), JSONObject().put("t", v.title).put("a", v.artist).put("b", v.album))
        }
        e.putString("favs", favs.joinToString(","))
        e.putString("pl", pl.toString())
        e.putString("ed", ed.toString())
        e.apply()
    }

    fun saveLast(id: Long, pos: Long, queue: String) {
        sp?.edit()?.putLong("li", id)?.putLong("lp", pos)?.putString("lq", queue)?.apply()
    }
    fun lastId(): Long = sp?.getLong("li", -1L) ?: -1L
    fun lastPos(): Long = sp?.getLong("lp", 0L) ?: 0L
    fun lastQueue(): String = sp?.getString("lq", "") ?: ""

    fun toggleFav(id: Long) { favs = if (id in favs) favs - id else favs + id; save() }
    fun createPlaylist(n: String) {
        if (playlists.none { it.name == n }) { playlists = playlists + Playlist(n, emptyList()); save() }
    }
    fun deletePlaylist(n: String) { playlists = playlists.filter { it.name != n }; save() }
    fun addTo(n: String, id: Long) {
        playlists = playlists.map { if (it.name == n && id !in it.ids) it.copy(ids = it.ids + id) else it }
        save()
    }
    fun removeFrom(n: String, id: Long) {
        playlists = playlists.map { if (it.name == n) it.copy(ids = it.ids.filter { x -> x != id }) else it }
        save()
    }
    fun renamePlaylist(old: String, new: String) {
        if (new.isEmpty() || (new != old && playlists.any { it.name == new })) return
        playlists = playlists.map { if (it.name == old) it.copy(name = new) else it }
        save()
    }
    fun move(n: String, id: Long, delta: Int) {
        playlists = playlists.map { p ->
            if (p.name != n) p else {
                val i = p.ids.indexOf(id)
                val j = i + delta
                if (i < 0 || j < 0 || j >= p.ids.size) p else {
                    val l = p.ids.toMutableList()
                    l.removeAt(i)
                    l.add(j, id)
                    p.copy(ids = l)
                }
            }
        }
        save()
    }
    fun setEdit(id: Long, e: TagEdit?) { edits = if (e == null) edits - id else edits + (id to e); save() }
}
